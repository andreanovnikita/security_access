require('es6-promise').polyfill();
require('console-polyfill');
global.asn1js = require('asn1js');
global.pkijs = require('pkijs');
